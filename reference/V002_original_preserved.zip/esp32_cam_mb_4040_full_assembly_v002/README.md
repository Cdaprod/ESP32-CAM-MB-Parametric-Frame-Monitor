# ESP32-CAM-MB | PARAMETRIC FRAME MONITOR — 4040 FULL ASSEMBLY V002

**One assembly, 18 BREP components, one assembled STEP, four printable STL components, six geometry-derived renders, an entirely offline browser viewer, and a colored GLB.** The 4040 extrusion and parametric sliding key are rebuilt from the recovered source geometry. The camera bracket and articulated joints are adapted from the V001 Python design, retaining its original source unchanged as `src/v001_mount.py`.

> **PROTOTYPE / DEMONSTRATOR ONLY.** The recovered 4040 shape is **photo-derived**; neither the 4040 profile nor the user's printer frame nor the ESP32-CAM-MB module has been verified with manufacturer dimensions/calipers. A 4.2-mm pilot for an M5 screw in a 3D-printed T-slot key is a conceptual threaded connection, **not a validated structural fastening method**. In service, favor tested metal M5 T-nuts/metal inserts and a verified rail-compatible adapter. The modeled screws are *nominal envelopes*, not helical-threaded bolts.

## 1 — Complete assembly

![Assembled 4040 extrusion, parametric T-slot key, camera arm and screw hardware](previews/assembled_oblique.png)

An **180-mm long 40×40 reference extrusion** sits along Z. The mount is attached to the **right-face slot centered at Y=+10 mm**, not the face center (which has no slot). The 4040 reference has two slots on each face, at ±10 mm. The base is 18 mm wide to fit the face around one slot, 51 mm tall, and 6 mm thick. A 60 mm arm carries the tilting ESP32-CAM + MB reference envelope.

The assembly is set to **yaw −22° and pitch +12°** for display. Positions in `COMPLETE_4040_ESP32_CAM_MB_ASSEMBLY.step` are already assembled; this is not a collection of coincident-origin parts.

### 2 — Exploded mounting sequence

![Exploded 4040 rail, V5 printed key, chassis plate and fasteners](previews/exploded_assembly.png)

1. Insert **V5 parametric printed key** through the end of the selected open 4040 slot. The original undercut and clearance parameters are retained.
2. Bring the 18 mm mounting plate to the 4040 right face at the slot center Y=+10, aligning its two mounting through-holes with the key's **Ø4.2 mm M5 pilot bores** at Z=±12.7.
3. Pass two **M5×8 socket-head screws** through the base (Ø5.5 mm clearance), into the V5 key pilot bores. The M5 head seats in Ø9×3 mm counterbores. The screw underhead length is 8 mm, with nominal tip at X=15 mm; the extrusion back wall is not penetrated in the geometry.
4. Use the **M4×25 yaw bolt**, washers/shim and M4 locknut at the base pivot.
5. Use the **M4×25 pitch bolt**, washers/shim and M4 locknut at the camera tilt lug.
6. Insert ESP32-CAM-MB via the cradle's open top, then secure cable strain relief. The actual board depth, lens and USB connector have **not** been measured or fit-tested.

### 3 — T-slot / extrusion interface

![True geometry-derived cross-section of recovered 4040 profile and undercut key](previews/4040_slot_fit_section.png)

The extrusion profile and printed key are represented as **real CAD solids**, not a generic 2020 T-nut model or drawing. The cross-sectional volume of the new 180 mm STEP-compatible extrusion differs by just ~0.01% from the previously exported 34 mm OpenSCAD reference STL when compared per unit length (remaining difference is surface tessellation).

| Feature | V002 dimension (mm) | Status |
|---|---:|---|
| Extrusion cross-section | 40 × 40 | Recovered photo-derived section |
| Slots per exterior face | 2 at ±10 | Recovered geometry |
| Selected mounting slot | Right face, Y=+10 | Assembled position |
| T-slot opening | 6.20 | Recovered nominal |
| Head cavity maximum width | 10.50 | Recovered nominal |
| Slot cavity depth | 6.80 | Recovered nominal |
| Key clearance | 0.18 per surface | Recovered nominal |
| Tongue recessed from face | 0.20 | Recovered V5 nominal |
| Printed key length | 45.0 | Parametric |
| Key M5 tap pilots | Ø4.20, Z±12.7 | Demonstrator |
| Base plate | 18 × 51 × 6 | Parametric |
| M5 plate clearance and counterbore | Ø5.5, Ø9 × 3 deep | Parametric |

![Mounted T-slot key and screws with extrusion hidden/translucent](previews/key_and_screws_detail.png)

### 4 — Camera assembly and joints

![M4 yaw pivot and pitch tilt hardware and ESP32-CAM-MB cradle](previews/camera_and_pivots.png)

![Front-facing optical reference and open-sided cradle](previews/camera_front_optics.png)

The original V001 model had a **measurable volume intersection** between the nominal camera stack and the cradle's pitch web. V002 resolves that by **lowering the distal pitch pivot by 9.5 mm**, retaining the original V001 design as a reference. This is a deliberate correction, not a claim that the original source already had clearance.

The camera body is a simplified envelope only: **nominal 27 × 40 mm PCB**, provisional **16 mm** assembled depth, and a simplified lens cylinder. It is *not* an accurate ESP32-CAM-MB PCB/connector model. Verify physical board, antenna, lens, USB plug, cable and heat clearance.

## 5 — Hardware BOM

| Item | Qty | Nominal design dimension | Notes |
|---|---:|---|---|
| Photo-derived 4040 reference extrusion | 1 | 40×40×180 | Demonstration length; use actual verified part in practice |
| Printed V5 undercut key with pilots | 1 | L45, 2× Ø4.2 | Tapped-plastic M5, demonstration **only** |
| Printed 4040 base plate | 1 | 18×51×6 | Installs outside extrusion face |
| Printed arm | 1 | 60 mm reach | Distal hinge lowered in V002 |
| Printed camera cradle | 1 | Nominal 27×40 board | Top-access, cable clearance unverified |
| M5 socket-head cap screw | 2 | M5×8, head Ø8.5×5 | Physical threads omitted in solid geometry |
| M4 socket-head cap screw | 2 | M4×25, head Ø7×4 | One yaw, one pitch |
| M4 normal washer | 4 | OD8, ID4.4, t1.0 | Two per pivot (approximate hardware) |
| M4 thin shim washer | 1 | OD8, ID4.4, t0.5 | Yaw joint gap, nonstandard shim |
| M4 gap shim washer | 1 | OD8, ID4.4, t1.3 | Pitch joint gap, nonstandard shim |
| M4 hex/locknut envelope | 2 | AF7, height4 | No nylon insert modeled |
| ESP32-CAM-MB | 1 | Nominal envelope only | Not supplied; real dimensions needed |

The unusual **0.5 mm and 1.3 mm shim thicknesses** come from the inherited joint geometry; they must be manufactured/selected to fit the actual screws and joints. They are not claimed to be standard M4 washers. Hole dimensions and bolt head dimensions are provisional nominal geometry.

## 6 — Files

| Path | Content |
|---|---|
| `step/COMPLETE_4040_ESP32_CAM_MB_ASSEMBLY.step` | **Entire assembled, correctly positioned 18-component STEP** |
| `step/4040_reference_extrusion.step` | Parametric 180 mm rail as a single BREP solid |
| `step/V5_profile_matched_key_M5_pilots.step` | Exact undercut V5 key adapted with two M5 pilot holes |
| `step/V001_mount_base_4040_slot_10.step` | 4040 right-slot fixed base |
| `step/V001_60mm_yaw_arm.step` | V002 clearance-corrected swivel arm |
| `step/V001_camera_tilt_cradle.step` | V002 clearance-corrected camera cradle |
| `stl/*.stl` | **Four printable solids** (key, base, arm, cradle) |
| `viewer/COMPLETE_ASSEMBLY.glb` | Full colored mesh assembly in actual assembled positions |
| `viewer/OPEN_IN_BROWSER_OFFLINE.html` | **Single-file, self-contained browser 3D viewer** with full JS bundled |
| `previews/*.png` | Six actual model-derived preview images used above |
| `src/build_assembly.py` | Main parametric assembly, M4/M5 models, positions, STEP and STL exports |
| `src/v001_mount.py` | Untouched V001 source to preserve upstream definitions/history |
| `src/render_assembly.py` | Model-derived VTK and Matplotlib preview renderer |
| `src/export_viewer.py` | GLB and portable HTML 3D exporter |
| `src/validate_assembly.py` | Solid/mesh validity, slot/fastener clearance and 9-pose tests |
| `reference/*.scad` | All three recovered original T-slot OpenSCAD source files |
| `docs/assembly_manifest.json` | Assembly parameter set and individual part volumes |
| `docs/validation.json` | Numeric verification report and physical-fit limitations |
| `docs/BOM.csv` | Fastener and printed-part inventory |

## 7 — Python build (Mac / Linux)

**Python 3.11+**, CadQuery, Shapely, Trimesh, NumPy, Plotly, VTK, Matplotlib, and Pillow. For example:

```bash
python -m pip install cadquery shapely trimesh numpy plotly vtk matplotlib pillow
python src/build_assembly.py
python src/validate_assembly.py
python src/export_viewer.py
# Linux headless image rendering with Xvfb:
xvfb-run -a python src/render_assembly.py
# On a desktop Mac, run the same last Python command without xvfb-run.
```

Modify `AssemblySpec` for `rail_length`, `active_slot_y`, `yaw_deg`, `pitch_deg` or fastener dimensions. Modify the inherited `Spec` via the `V=replace(Spec(),...)` line for mount height, plate thickness, arm reach, T-slot profile parameters and camera envelope. **All STEP solids are regenerated directly from Python**; the program never fabricates a visual drawing in lieu of a model.

## 8 — Validated / not validated

**Validated computationally:** 18 BREP components individually valid, 4 printable watertight STL solids with matching volumes, zero positive-volume collisions between extrusion/key, extrusion/plate, base/arm, arm/cradle, cradle/nominal camera envelope, no M5 screw contact with metal extrusion, and nine yaw/pitch combinations tested for print-part and camera-envelope collisions. The **nominal** M5 screw shafts intentionally overlap the smaller tapped-plastic pilots, as real threads must engage material.

**Not validated physically:** real extrusion, print tolerances, M5 plastic thread capacity, fastener tightening torque, PCB revision, actual printed-part mechanical strength, USB/antenna location, optical field of view, and collision with any printer's moving bed/gantry. The shown **4040 is not automatically compatible with the Neptune 2's other V-slot sections**; a separate correctly dimensioned chassis adapter may be required.

## Origin / provenance

The recovered parametric SCAD files are included unchanged. This model uses their undercut and slot spacing; the V001 mount Python source is also included unchanged for traceability. The new `build_assembly.py` reconstitutes the reference extrusion as a geometric solid and adds physical installation positions, fasteners and V002 pitch-joint clearance corrections. No manufacturer-certified 4040 STEP model was supplied or asserted.
